# Editeur PDF — Version locale Windows

Outil d'édition de PDF (fusion de pages, ajout d'images, rotation,
impression...) qui fonctionne **entièrement hors ligne**, directement
dans votre navigateur. Aucune donnée n'est envoyée sur internet : tout
reste sur votre machine.

## Contenu du dossier

```
editeur-pdf-windows/
├── lancer-editeur.bat            <- a lancer (double-clic)
├── server.py                     <- petit serveur local (ne pas toucher)
├── PDF_Image_Editor_MultiPDF.html <- l'outil lui-meme
├── pdf.min.mjs                   <- bibliotheque PDF.js
└── pdf.worker.min.mjs            <- bibliotheque PDF.js (worker)
```

## Pré-requis

**Python** doit être installé sur la machine (une seule fois).

- Téléchargement : https://www.python.org/downloads/
- Pendant l'installation, cochez bien la case **"Add Python to PATH"**
  (ou "Ajouter Python au PATH").
- Vous pouvez vérifier que c'est fait en ouvrant une invite de
  commandes (`cmd`) et en tapant : `python --version`

Pourquoi Python est nécessaire : la version actuelle de PDF.js (la
bibliothèque qui affiche les PDF) ne peut pas être ouverte par un
simple double-clic sur le fichier HTML — les navigateurs bloquent ce
type de fichier par sécurité en dehors d'un serveur. `server.py` crée
donc un mini-serveur **local uniquement** (adresse `127.0.0.1`,
jamais accessible depuis l'extérieur) pour contourner cette
limitation, sans jamais passer par internet.

## Utilisation

1. Vérifiez que les 5 fichiers listés ci-dessus sont bien dans le
   même dossier.
2. Double-cliquez sur **`lancer-editeur.bat`**.
3. Une fenêtre de commande s'ouvre brièvement, puis l'outil s'ouvre
   automatiquement dans votre navigateur par défaut.
4. Travaillez normalement dans l'outil (import de PDF, d'images,
   édition, impression...).
5. Quand vous avez terminé, **fermez simplement l'onglet ou la
   fenêtre du navigateur** : le serveur local s'arrête tout seul,
   automatiquement.

Vous n'avez rien d'autre à faire. Pas besoin de fermer manuellement
une fenêtre de terminal.

## Sécurité

- Le serveur n'écoute que sur `127.0.0.1` (votre propre machine) :
  il n'est **jamais accessible** depuis un autre ordinateur ou depuis
  internet.
- Aucune connexion internet n'est utilisée ni requise après
  l'installation initiale de Python.
- Un avertissement s'affiche dans l'outil à chaque ouverture et à
  chaque import de fichier, pour vous rappeler de vérifier la
  provenance de vos PDF et images avant de les charger.

## Problèmes fréquents

**"Python n'a pas ete trouve sur cette machine"**
→ Installez Python (voir Pré-requis ci-dessus), en cochant bien
"Add Python to PATH", puis relancez `lancer-editeur.bat`.

**Le navigateur affiche une page blanche ou une erreur de chargement**
→ Vérifiez que `pdf.min.mjs` et `pdf.worker.min.mjs` sont bien
présents dans le dossier, à côté du fichier HTML.

**J'ai rechargé la page (F5) et l'outil ne répond plus**
→ C'est normal : recharger la page ferme aussi le serveur local
(la même détection sert à l'arrêter quand vous fermez l'onglet).
Relancez simplement `lancer-editeur.bat`.

**Le port 8000 est déjà utilisé / rien ne s'ouvre**
→ Un autre programme utilise peut-être déjà ce port. Fermez les
autres serveurs locaux éventuels puis relancez, ou modifiez le
numéro de port (`PORT=8000`) en haut de `lancer-editeur.bat` et dans
`server.py` (mettez la même valeur dans les deux fichiers, par
exemple `8001`).

**Antivirus / SmartScreen bloque le fichier .bat**
→ C'est un comportement normal de Windows avec les scripts
téléchargés d'origine inconnue. Vérifiez le contenu du fichier
(il est en texte brut, lisible avec le Bloc-notes) puis autorisez
son exécution si vous en êtes bien à l'origine.
