"""
Petit serveur local pour l'editeur PDF.
- Sert les fichiers du dossier courant (HTML, .mjs, etc.)
- Ecoute uniquement sur 127.0.0.1 (jamais accessible depuis l'exterieur)
- S'arrete automatiquement quand la page web envoie un signal
  a l'adresse /__shutdown__ (voir PDF_Image_Editor_MultiPDF.html,
  evenement "pagehide").
"""

import http.server
import os
import socketserver
import sys
import threading

PORT = 8000

os.chdir(os.path.dirname(os.path.abspath(__file__)))


class Handler(http.server.SimpleHTTPRequestHandler):

    def do_POST(self):
        if self.path == "/__shutdown__":
            self.send_response(204)
            self.end_headers()
            # Arret dans un thread separe pour ne pas bloquer
            # la requete en cours (shutdown() attend la fin
            # de la boucle serve_forever()).
            threading.Thread(target=self.server.shutdown, daemon=True).start()
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format, *args):
        # Reduit le bruit dans la console.
        sys.stderr.write(
            "[serveur local] " + (format % args) + "\n"
        )


class ReusableServer(socketserver.TCPServer):
    allow_reuse_address = True


if __name__ == "__main__":
    with ReusableServer(("127.0.0.1", PORT), Handler) as httpd:
        print("============================================")
        print("  Serveur local demarre")
        print("  http://localhost:%d" % PORT)
        print("  (ferme automatiquement la page web pour l'arreter)")
        print("============================================")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            pass
        print("Serveur arrete.")
