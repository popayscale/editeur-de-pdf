@echo off
setlocal
title Editeur PDF - Serveur local
cd /d "%~dp0"

set PORT=8000
set PYCMD=

echo ============================================
echo   Editeur PDF - lancement du serveur local
echo   Rien n'est envoye sur internet
echo ============================================
echo.

where python >nul 2>nul
if not errorlevel 1 set PYCMD=python

if not defined PYCMD (
    where python3 >nul 2>nul
    if not errorlevel 1 set PYCMD=python3
)

if not defined PYCMD goto :nopython

echo Python detecte : %PYCMD%
echo.

start "Serveur local - Editeur PDF" /min cmd /c "%PYCMD% server.py"

timeout /t 1 /nobreak >nul

start "" "http://localhost:%PORT%/PDF_Image_Editor_MultiPDF.html"

echo.
echo L'outil s'est ouvert dans votre navigateur.
echo Le serveur s'arretera automatiquement a la fermeture de l'onglet.
echo Cette fenetre peut etre fermee.
echo.
timeout /t 3 >nul
exit /b 0

:nopython
echo Python n'a pas ete trouve sur cette machine.
echo Installez Python depuis python.org puis relancez ce fichier.
echo Pensez a cocher la case Add Python to PATH pendant l'installation.
pause
exit /b 1
